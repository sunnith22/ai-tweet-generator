import {
  PROCESS_FETCH,
  PROCESS_SUCCESS,
  PROCESS_FAILURE,
  PROCESS3_FETCH,
  PROCESS3_SUCCESS,
  PROCESS3_FAILURE,
  SET_PROCESS_NO,
  PROCESS_ONE_DAY_FETCH,
  PROCESS_ONE_DAY_SUCCESS,
  PROCESS_ONE_DAY_FAILURE,
  PROCESS_RANGE_FETCH,
  PROCESS_RANGE_SUCCESS,
  PROCESS_RANGE_FAILURE,
  SET_FROM_DATE,
  SET_TO_DATE,
  PROCESS_ENGINE_FETCH,
  PROCESS_ENGINE_SUCCESS,
  PROCESS_ENGINE_FAILURE,
  PROCESS_ENGINE_DATE_FETCH,
  PROCESS_ENGINE_DATE_SUCCESS,
  PROCESS_ENGINE_DATE_FAILURE,
  SET_PROCESS_NAME,
  PROCESS_CASTING_NO_FETCH,
  PROCESS_CASTING_NO_SUCCESS,
  PROCESS_CASTING_NO_FAILURE,
  CLEAR,
  EXCEL_TABLE_HEADING,
} from "./processTypes";

var tempFromDate = new Date(Date.now());

tempFromDate.setDate(tempFromDate.getDate() - 1);
tempFromDate.setHours(23);
tempFromDate.setMinutes(60);
tempFromDate.setSeconds(1);

var tempToDate = new Date(Date.now());
tempToDate.setHours(23);
tempToDate.setMinutes(59);
tempToDate.setSeconds(59);

const initialStateProcess = {
  loading: false,
  machiningDataLoading: false,
  loading3: false,
  error: "",
  error3: "",
  processNo: "",
  processName: "",
  fromDate: tempFromDate.toISOString(),
  toDate: tempToDate.toISOString(),
  data: {},
  data3: {},
  dataOneDay: {},
  dataRange: {},
  processEngine: {},
  processEngineDate: {},
  excelTableHeading: [],
};

const processReducer = (state = initialStateProcess, action) => {
  switch (action.type) {
    case SET_PROCESS_NO:
      return {
        ...state,
        processNo: action.processNo,
        processName: action.processName,
      };
    case PROCESS_FETCH:
      return {
        ...state,
        machiningDataLoading: true,
      };
    case PROCESS_SUCCESS:
      return {
        ...state,
        machiningDataLoading: false,
        data: action.payload,
        error: "",
      };
    case PROCESS_FAILURE:
      return {
        ...state,
        machiningDataLoading: false,
        data: [],
        error: action.error,
      };
    case PROCESS3_FETCH:
      return {
        ...state,
        loading3: true,
      };
    case PROCESS3_SUCCESS:
      return {
        ...state,
        loading3: false,
        data3: action.payload,
        error3: "",
      };
    case PROCESS3_FAILURE:
      return {
        ...state,
        loading3: false,
        data3: [],
        error3: action.error,
      };
    case PROCESS_ONE_DAY_FETCH:
      return {
        ...state,
        loading: true,
      };
    case PROCESS_ONE_DAY_SUCCESS:
      return {
        ...state,
        loading: false,
        dataOneDay: action.payload,
        error: "",
      };
    case PROCESS_ONE_DAY_FAILURE:
      return {
        ...state,
        loading: false,
        dataOneDay: {},
        error: action.error,
      };
    case PROCESS_RANGE_FETCH:
      return {
        ...state,
        loading: true,
      };
    case PROCESS_RANGE_SUCCESS:
      return {
        ...state,
        loading: false,
        dataRange: action.payload,
        error: "",
      };
    case PROCESS_RANGE_FAILURE:
      return {
        ...state,
        loading: false,
        dataRange: {},
        error: action.error,
      };
    case SET_FROM_DATE:
      return {
        ...state,
        fromDate: action.payload,
      };
    case SET_TO_DATE:
      return {
        ...state,
        toDate: action.payload,
      };

    case PROCESS_ENGINE_FETCH:
      return {
        ...state,
        loading: true,
      };
    case PROCESS_ENGINE_SUCCESS:
      return {
        ...state,
        loading: false,
        processEngine: action.payload,
        error: "",
      };
    case PROCESS_ENGINE_FAILURE:
      return {
        ...state,
        loading: false,
        processEngine: {},
        error: action.error,
      };

    case PROCESS_ENGINE_DATE_FETCH:
      return {
        ...state,
        loading: true,
      };
    case PROCESS_ENGINE_DATE_SUCCESS:
      return {
        ...state,
        loading: false,
        processEngineDate: action.payload,
        error: "",
      };
    case PROCESS_ENGINE_DATE_FAILURE:
      return {
        ...state,
        loading: false,
        processEngineDate: {},
        error: action.error,
      };
    case SET_PROCESS_NAME:
      return {
        ...state,
        processName: action.payload,
      };

    case PROCESS_CASTING_NO_FETCH:
      return {
        ...state,
        loading: true,
      };
    case PROCESS_CASTING_NO_SUCCESS:
      return {
        ...state,
        loading: false,
        dataRange: action.payload,
        error: "",
      };
    case PROCESS_CASTING_NO_FAILURE:
      return {
        ...state,
        loading: false,
        dataRange: {},
        error: action.error,
      };
    case EXCEL_TABLE_HEADING:
      return {
        ...state,
        excelTableHeading: action.payload,
      };
    case CLEAR:
      return initialStateProcess;

    default:
      return state;
  }
};

export default processReducer;
