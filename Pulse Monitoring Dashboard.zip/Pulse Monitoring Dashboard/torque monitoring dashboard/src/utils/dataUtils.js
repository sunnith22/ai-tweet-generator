export const formatDate = (date) => {
  return date.toISOString().slice(0, 10).replace(/-/g, '');
};

export const formatChartData = (data, station) => {
  return data.map(item => ({
    time: new Date(item['Reception date/time']).toLocaleTimeString(),
    torque: parseFloat(item.Torque),
    timestamp: new Date(item['Reception date/time']).getTime(),
    station: station
  })).sort((a, b) => a.timestamp - b.timestamp);
};