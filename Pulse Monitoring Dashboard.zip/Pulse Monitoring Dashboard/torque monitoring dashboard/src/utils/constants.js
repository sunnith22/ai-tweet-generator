export const STATIONS = [53, 55, 60, 61, 62];

export const STATION_COLORS = {
  53: '#3B82F6', // Blue
  55: '#EF4444', // Red
  60: '#10B981', // Green
  61: '#F59E0B', // Yellow
  62: '#8B5CF6'  // Purple
};