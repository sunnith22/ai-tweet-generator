import React from 'react';
import { Activity, AlertCircle, CheckCircle, Loader } from 'lucide-react';
import './StatusPanel.css';

const StatusPanel = ({ loading, error, dataCount, isLive }) => {
  const getStatusIcon = () => {
    if (loading) return <Loader className="spinning" size={16} />;
    if (error) return <AlertCircle size={16} />;
    return <CheckCircle size={16} />;
  };

  const getStatusText = () => {
    if (loading) return 'Loading data...';
    if (error) return 'Connection error';
    return isLive ? 'Live monitoring' : 'Connected';
  };

  const getStatusClass = () => {
    if (loading) return 'status-loading';
    if (error) return 'status-error';
    return isLive ? 'status-live' : 'status-connected';
  };

  return (
    <div className="status-panel">
      <div className={`status-indicator ${getStatusClass()}`}>
        {getStatusIcon()}
        <span>{getStatusText()}</span>
      </div>
      
      <div className="data-summary">
        <Activity size={16} />
        <span>Total data points: {dataCount}</span>
      </div>
      
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
    </div>
  );
};

export default StatusPanel;
