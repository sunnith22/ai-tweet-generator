import React, { useState, useEffect, useCallback } from 'react';
import Header from './Header';
import StationChart from './StationChart';
import StatusPanel from './StatusPanel';
import { TorqueAPI } from '../services/api';
import { formatDate, formatChartData } from '../utils/dataUtils';
import { STATIONS } from '../utils/constants';
import './Dashboard.css';

const Dashboard = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [allStationData, setAllStationData] = useState({});
  const [isLive, setIsLive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState('Never');

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const dateStr = formatDate(selectedDate);
      const promises = STATIONS.map(station => 
        TorqueAPI.fetchTorqueData(station, dateStr).then(data => ({ station, data }))
      );
      
      const results = await Promise.all(promises);
      const newData = {};
      
      results.forEach(({ station, data }) => {
        if (data && data.data) {
          newData[station] = formatChartData(data.data, station);
        } else {
          newData[station] = [];
        }
      });
      
      setAllStationData(newData);
      setLastUpdate(new Date().toLocaleTimeString());
    } catch (err) {
      setError(`Failed to fetch data: ${err.message}`);
    } finally {
      setLoading(false);
    }
  }, [selectedDate]);

  // Live data effect
  useEffect(() => {
    let interval;
    if (isLive) {
      fetchData();
      interval = setInterval(fetchData, 10000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLive, fetchData]);

  // Initial data fetch
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const totalDataPoints = Object.values(allStationData).reduce((sum, data) => sum + data.length, 0);

  return (
    <div className="dashboard">
      <Header 
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        isLive={isLive}
        onToggleLive={setIsLive}
        onRefresh={fetchData}
        lastUpdate={lastUpdate}
      />
      
      <main className="dashboard-content">
        <StatusPanel 
          loading={loading}
          error={error}
          dataCount={totalDataPoints}
          isLive={isLive}
        />
        
        <div className="charts-grid">
          {STATIONS.map(station => (
            <StationChart 
              key={station}
              station={station}
              data={allStationData[station] || []}
              loading={loading}
            />
          ))}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;