import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Calendar, Play, Pause, RefreshCw } from 'lucide-react';
import './Header.css';

const Header = ({ selectedDate, onDateChange, isLive, onToggleLive, onRefresh, lastUpdate }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleDateChange = (e) => {
    onDateChange(new Date(e.target.value));
  };

  const formatDateForInput = (date) => {
    return date.toISOString().split('T')[0];
  };

  return (
    <header className="header">
      <div className="header-main">
        <div className="header-title">
          <h1>Torque Data Dashboard</h1>
          <p>Real-time torque monitoring for manufacturing stations</p>
        </div>
        
        <div className="header-controls">
          <div className="live-status">
            <div className={`status-dot ${isLive ? 'live' : 'offline'}`}></div>
            <span>Last update: {lastUpdate}</span>
          </div>
          
          <button 
            className="expand-btn"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            Controls
          </button>
        </div>
      </div>
      
      {isExpanded && (
        <div className="header-expanded">
          <div className="date-selector">
            <Calendar size={20} />
            <label htmlFor="date-input">Select Date:</label>
            <input 
              id="date-input"
              type="date"
              value={formatDateForInput(selectedDate)}
              onChange={handleDateChange}
              max={formatDateForInput(new Date())}
            />
          </div>
          
          <div className="action-buttons">
            <button
              className={`btn ${isLive ? 'btn-danger' : 'btn-success'}`}
              onClick={() => onToggleLive(!isLive)}
            >
              {isLive ? <Pause size={16} /> : <Play size={16} />}
              {isLive ? 'Stop Live' : 'Start Live'}
            </button>
            
            <button
              className="btn btn-primary"
              onClick={onRefresh}
            >
              <RefreshCw size={16} />
              Refresh
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;