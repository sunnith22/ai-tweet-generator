import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { STATION_COLORS } from '../utils/constants';
import './StationChart.css';

const StationChart = ({ station, data, loading }) => {
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="chart-tooltip">
          <p className="tooltip-time">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="tooltip-value" style={{ color: entry.color }}>
              {`Torque: ${entry.value} Nm`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="station-chart">
      <div className="chart-header">
        <h3 style={{ color: STATION_COLORS[station] }}>
          Station {station}
        </h3>
        <div className="chart-info">
          <span className="data-count">{data.length} points</span>
          {loading && <span className="loading-indicator">Loading...</span>}
        </div>
      </div>
      
      <div className="chart-container">
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis 
              dataKey="time" 
              stroke="#6B7280"
              fontSize={11}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis 
              stroke="#6B7280"
              fontSize={11}
              label={{ value: 'Torque (Nm)', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line
              type="monotone"
              dataKey="torque"
              stroke={STATION_COLORS[station]}
              strokeWidth={2}
              dot={{ fill: STATION_COLORS[station], strokeWidth: 2, r: 3 }}
              connectNulls={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default StationChart;