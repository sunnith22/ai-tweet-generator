export const TorqueAPI = {
  async fetchTorqueData(station, date) {
    try {
      const response = await fetch(`http://10.82.126.73:8121/api/torque-data?station=${station}&date=${date}`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`Error fetching data for station ${station}:`, error);
      return null;
    }
  }
};